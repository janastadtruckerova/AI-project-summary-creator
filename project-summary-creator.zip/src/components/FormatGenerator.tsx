import React, { useState } from "react";
import {
  Briefcase,
  Linkedin,
  FileSpreadsheet,
  Building2,
  Sparkles,
  Copy,
  Check,
  Download,
  Printer,
  Edit3,
  Save,
  CheckCircle2,
  AlertCircle,
  RefreshCw
} from "lucide-react";
import { FormatType, FormattedOutputs, ProjectSummary } from "../types";

interface FormatGeneratorProps {
  summary: ProjectSummary;
  formattedOutputs: FormattedOutputs;
  activeFormat: FormatType;
  setActiveFormat: (format: FormatType) => void;
  onGenerateFormat: (format: FormatType) => Promise<void>;
  onUpdateFormatContent: (format: FormatType, content: string) => void;
  isGenerating: boolean;
  originalText?: string;
}

const FORMAT_CONFIG: Record<
  FormatType,
  {
    icon: React.ElementType;
    description: string;
    rules: string;
    targetWordCount?: string;
    badgeColor: string;
  }
> = {
  "Portfolio Summary": {
    icon: Briefcase,
    description: "A structured project description suitable for a personal AI portfolio.",
    rules: "Detailed technical architecture, problem statement, tools used, and business value.",
    badgeColor: "bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800",
  },
  "LinkedIn Summary": {
    icon: Linkedin,
    description: "An engaging professional LinkedIn post focusing on learning outcomes and impact.",
    rules: "Length MUST be strictly between 150 - 250 words.",
    targetWordCount: "150-250 words",
    badgeColor: "bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border-blue-200 dark:border-blue-800",
  },
  "CV Summary": {
    icon: FileSpreadsheet,
    description: "3-5 concise resume bullet points focused on achievements and business impact.",
    rules: "3-5 bullet points starting with strong action verbs.",
    targetWordCount: "3-5 bullet points",
    badgeColor: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800",
  },
  "Executive Summary": {
    icon: Building2,
    description: "A business-focused summary for managers and stakeholders using clear language.",
    rules: "Non-technical language where possible. Maximum length: 200 words.",
    targetWordCount: "Max 200 words",
    badgeColor: "bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border-purple-200 dark:border-purple-800",
  },
};

export const FormatGenerator: React.FC<FormatGeneratorProps> = ({
  summary,
  formattedOutputs,
  activeFormat,
  setActiveFormat,
  onGenerateFormat,
  onUpdateFormatContent,
  isGenerating,
}) => {
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState("");

  const content = formattedOutputs[activeFormat] || "";
  const currentConfig = FORMAT_CONFIG[activeFormat];
  const Icon = currentConfig.icon;

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const bulletCount = (content.match(/^[•\-\*]\s+/gm) || []).length;

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadTxt = () => {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${activeFormat.toLowerCase().replace(/\s+/g, "_")}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>${activeFormat}</title>
          <style>
            body { font-family: system-ui, sans-serif; padding: 40px; line-height: 1.6; color: #1e293b; max-width: 800px; margin: 0 auto; }
            h1 { font-size: 20px; color: #334155; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; }
            pre { white-space: pre-wrap; font-family: inherit; font-size: 14px; }
          </style>
        </head>
        <body>
          <h1>${activeFormat}</h1>
          <pre>${content}</pre>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  // Word count check validation
  const getValidationBadge = () => {
    if (!content) return null;

    if (activeFormat === "LinkedIn Summary") {
      const isValid = wordCount >= 150 && wordCount <= 250;
      return (
        <span
          className={`inline-flex items-center space-x-1 px-2.5 py-1 text-xs font-semibold rounded-full border ${
            isValid
              ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800"
              : "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-amber-200 dark:border-amber-800"
          }`}
        >
          {isValid ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
          <span>{wordCount} words (Target: 150-250)</span>
        </span>
      );
    }

    if (activeFormat === "Executive Summary") {
      const isValid = wordCount <= 200;
      return (
        <span
          className={`inline-flex items-center space-x-1 px-2.5 py-1 text-xs font-semibold rounded-full border ${
            isValid
              ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800"
              : "bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-amber-200 dark:border-amber-800"
          }`}
        >
          {isValid ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
          <span>{wordCount} words (Target: Max 200)</span>
        </span>
      );
    }

    if (activeFormat === "CV Summary") {
      const isValid = bulletCount >= 3 && bulletCount <= 5;
      return (
        <span
          className={`inline-flex items-center space-x-1 px-2.5 py-1 text-xs font-semibold rounded-full border ${
            isValid || bulletCount > 0
              ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800"
              : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700"
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>{bulletCount > 0 ? `${bulletCount} bullets` : `${wordCount} words`}</span>
        </span>
      );
    }

    return (
      <span className="px-2.5 py-1 text-xs font-semibold rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
        {wordCount} words
      </span>
    );
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden transition-all">
      {/* Title & Format Tabs */}
      <div className="p-6 border-b border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/30">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <span>Select Tailored Output Format</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Transform the project summary into specific career & professional formats
            </p>
          </div>
        </div>

        {/* Format Selection Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {(Object.keys(FORMAT_CONFIG) as FormatType[]).map((fmt) => {
            const cfg = FORMAT_CONFIG[fmt];
            const FormatIcon = cfg.icon;
            const isSelected = activeFormat === fmt;
            const hasGenerated = !!formattedOutputs[fmt];

            return (
              <button
                key={fmt}
                type="button"
                onClick={() => {
                  setActiveFormat(fmt);
                  setIsEditing(false);
                }}
                className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                  isSelected
                    ? "bg-white dark:bg-slate-800 border-indigo-600 dark:border-indigo-500 shadow-md ring-2 ring-indigo-500/20"
                    : "bg-white/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <div
                      className={`p-1.5 rounded-lg ${
                        isSelected
                          ? "bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300"
                          : "bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300"
                      }`}
                    >
                      <FormatIcon className="w-4 h-4" />
                    </div>
                    {hasGenerated && (
                      <span className="w-2 h-2 rounded-full bg-emerald-500" title="Generated" />
                    )}
                  </div>
                  <h3
                    className={`text-xs font-bold ${
                      isSelected
                        ? "text-indigo-600 dark:text-indigo-400"
                        : "text-slate-900 dark:text-white"
                    }`}
                  >
                    {fmt}
                  </h3>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                  {cfg.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Format Details & Action Header */}
      <div className="p-6">
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700/80 mb-5 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 mt-0.5">
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  {activeFormat}
                </h3>
                <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${currentConfig.badgeColor}`}>
                  {currentConfig.rules}
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                {currentConfig.description}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onGenerateFormat(activeFormat)}
            disabled={isGenerating}
            className="inline-flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-50 transition-colors shadow-sm cursor-pointer"
          >
            {isGenerating ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Generating {activeFormat}...</span>
              </>
            ) : content ? (
              <>
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Regenerate Format</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Generate {activeFormat}</span>
              </>
            )}
          </button>
        </div>

        {/* Content Viewer / Editor */}
        {isGenerating ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-8 h-8 border-3 border-indigo-600/20 border-t-indigo-600 rounded-full animate-spin mx-auto" />
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Generating tailored {activeFormat}...
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
              Analyzing facts and applying strict word count and formatting constraints.
            </p>
          </div>
        ) : content ? (
          <div className="space-y-4">
            {/* Toolbar above output */}
            <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
              <div className="flex items-center space-x-2">
                {getValidationBadge()}
              </div>

              <div className="flex items-center space-x-2">
                {!isEditing ? (
                  <button
                    type="button"
                    onClick={() => {
                      setEditText(content);
                      setIsEditing(true);
                    }}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateFormatContent(activeFormat, editText);
                      setIsEditing(false);
                    }}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Text</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleCopy}
                  className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                      <span className="text-emerald-600 dark:text-emerald-400">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleDownloadTxt}
                  className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  title="Download as TXT"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">TXT</span>
                </button>

                <button
                  type="button"
                  onClick={handlePrint}
                  className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  title="Print or Save PDF"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Print/PDF</span>
                </button>
              </div>
            </div>

            {/* Generated Text Box */}
            {isEditing ? (
              <textarea
                rows={12}
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                className="w-full p-4 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs font-mono leading-relaxed focus:ring-2 focus:ring-indigo-500"
              />
            ) : (
              <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 text-slate-900 dark:text-slate-100 text-xs leading-relaxed whitespace-pre-wrap select-text font-sans">
                {content}
              </div>
            )}
          </div>
        ) : (
          <div className="p-10 text-center space-y-3 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50/30 dark:bg-slate-900/20">
            <Icon className="w-8 h-8 text-indigo-500/60 mx-auto" />
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Ready to generate {activeFormat}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Click "Generate {activeFormat}" to convert the structured summary into this format.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
