import React, { useState, useRef } from "react";
import {
  Upload,
  FileText,
  Trash2,
  Zap,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  ArrowRight,
  FileSpreadsheet,
  Check,
  Briefcase,
  Linkedin,
  Building2,
  Layers
} from "lucide-react";
import { SAMPLE_TEMPLATES } from "../data/sampleTemplates";
import { FormatType, SampleProjectTemplate } from "../types";

interface DocumentInputPanelProps {
  projectText: string;
  setProjectText: (text: string) => void;
  fileData: { data: string; mimeType: string; name: string } | null;
  setFileData: (data: { data: string; mimeType: string; name: string } | null) => void;
  selectedFormats: FormatType[];
  setSelectedFormats: (formats: FormatType[]) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
  error: string | null;
}

const ALL_FORMAT_TYPES: {
  id: FormatType;
  title: string;
  icon: React.ElementType;
  description: string;
  rule: string;
}[] = [
  {
    id: "Portfolio Summary",
    title: "Portfolio Summary",
    icon: Briefcase,
    description: "Detailed case-study style layout for your personal website.",
    rule: "Full technical overview & impact",
  },
  {
    id: "LinkedIn Summary",
    title: "LinkedIn Summary",
    icon: Linkedin,
    description: "Engaging post with learning outcomes and reach.",
    rule: "150 - 250 words",
  },
  {
    id: "CV Summary",
    title: "CV Summary",
    icon: FileSpreadsheet,
    description: "Impactful bullet points optimized for recruiters.",
    rule: "3-5 action-verb bullets",
  },
  {
    id: "Executive Summary",
    title: "Executive Summary",
    icon: Building2,
    description: "High-level business focused summary for managers.",
    rule: "Max 200 words, non-technical",
  },
];

export const DocumentInputPanel: React.FC<DocumentInputPanelProps> = ({
  projectText,
  setProjectText,
  fileData,
  setFileData,
  selectedFormats,
  setSelectedFormats,
  onAnalyze,
  isAnalyzing,
  error,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const wordCount = projectText.trim() ? projectText.trim().split(/\s+/).length : 0;
  const charCount = projectText.length;

  const handleFileUpload = (file: File) => {
    if (!file) return;

    const reader = new FileReader();

    if (file.type === "text/plain" || file.name.endsWith(".txt") || file.name.endsWith(".md")) {
      reader.onload = (e) => {
        const content = e.target?.result as string;
        if (content) {
          setProjectText(content);
          setFileData(null);
        }
      };
      reader.readAsText(file);
    } else {
      reader.onload = (e) => {
        const result = e.target?.result as string;
        if (result) {
          const base64Data = result.split(",")[1];
          let mimeType = file.type || "application/pdf";
          if (file.name.endsWith(".pdf")) mimeType = "application/pdf";
          if (file.name.endsWith(".docx")) mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
          if (file.name.endsWith(".doc")) mimeType = "application/msword";

          setFileData({
            data: base64Data,
            mimeType,
            name: file.name,
          });

          if (!projectText) {
            setProjectText(`[Attached file: ${file.name}]`);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const loadSample = (template: SampleProjectTemplate) => {
    setProjectText(template.content);
    setFileData(null);
  };

  const toggleFormat = (fmt: FormatType) => {
    if (selectedFormats.includes(fmt)) {
      // Prevent unselecting all formats
      if (selectedFormats.length > 1) {
        setSelectedFormats(selectedFormats.filter((f) => f !== fmt));
      }
    } else {
      setSelectedFormats([...selectedFormats, fmt]);
    }
  };

  const selectAllFormats = () => {
    if (selectedFormats.length === ALL_FORMAT_TYPES.length) {
      setSelectedFormats(["Portfolio Summary"]);
    } else {
      setSelectedFormats(ALL_FORMAT_TYPES.map((f) => f.id));
    }
  };

  const areAllSelected = selectedFormats.length === ALL_FORMAT_TYPES.length;

  return (
    <div className="space-y-6">
      {/* Sample Templates Section */}
      <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200 dark:border-slate-700/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-amber-500" />
            <h2 className="text-xs font-semibold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              Quick Test Sample Projects
            </h2>
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Click to auto-populate documentation
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          {SAMPLE_TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.id}
              type="button"
              onClick={() => loadSample(tmpl)}
              className="group text-left p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-indigo-400 dark:hover:border-indigo-500 hover:shadow-sm transition-all flex flex-col justify-between"
            >
              <div>
                <span
                  className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded-full border mb-1.5 ${tmpl.badgeColor}`}
                >
                  {tmpl.category}
                </span>
                <h3 className="text-xs font-semibold text-slate-900 dark:text-white line-clamp-2 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                  {tmpl.title}
                </h3>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                {tmpl.description}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Main Input Box & Upload Zone */}
      <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div>
          <div className="flex items-center justify-between mb-3">
            <label className="text-base font-bold text-slate-900 dark:text-white flex items-center space-x-2">
              <FileText className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <span>Project Documentation or Description</span>
            </label>
            <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center space-x-3">
              <span>{wordCount} words</span>
              <span>•</span>
              <span>{charCount} characters</span>
            </div>
          </div>

          {/* Upload Dropzone Header */}
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`relative border-2 border-dashed rounded-xl p-4 text-center transition-all mb-4 ${
              dragActive
                ? "border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/30"
                : "border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/40 hover:border-slate-300 dark:hover:border-slate-600"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.docx,.doc,.txt,.md"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleFileUpload(e.target.files[0]);
                }
              }}
            />

            {fileData ? (
              <div className="flex items-center justify-between bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-indigo-200 dark:border-indigo-900">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-semibold text-slate-900 dark:text-white">
                      {fileData.name}
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      Document attached for multi-modal Gemini analysis
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setFileData(null)}
                  className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                  title="Remove attached file"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-center space-x-2 text-xs text-slate-600 dark:text-slate-400">
                <Upload className="w-4 h-4 text-indigo-500" />
                <span>
                  Drag & drop project document (PDF, Word, TXT, MD) or{" "}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    browse computer
                  </button>
                </span>
              </div>
            )}
          </div>

          {/* Text Area Input */}
          <div className="relative">
            <textarea
              rows={8}
              value={projectText}
              onChange={(e) => setProjectText(e.target.value)}
              placeholder={`Paste project notes, PDF content, project proposal, charter, or description here...

Example structure:
- Project background & business challenge
- Implemented solution & workflow
- Tools, models & technologies used
- Final deliverables & outputs
- Quantified business impact & results`}
              className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 font-mono text-xs leading-relaxed transition-all resize-y"
            />

            {projectText && (
              <button
                type="button"
                onClick={() => {
                  setProjectText("");
                  setFileData(null);
                }}
                className="absolute top-3 right-3 p-1.5 text-slate-400 hover:text-rose-500 bg-slate-100 dark:bg-slate-800 rounded-lg transition-colors"
                title="Clear input"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Output Format Selection Section (NEW: Select desired output format right away) */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center space-x-2">
                <Layers className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>Choose Summary Format(s) to Generate</span>
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Select which format(s) you want generated immediately upon analysis
              </p>
            </div>
            <button
              type="button"
              onClick={selectAllFormats}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline px-2 py-1 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors"
            >
              {areAllSelected ? "Deselect Extra Formats" : "✨ Select All Formats"}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {ALL_FORMAT_TYPES.map((fmt) => {
              const isSelected = selectedFormats.includes(fmt.id);
              const Icon = fmt.icon;

              return (
                <div
                  key={fmt.id}
                  onClick={() => toggleFormat(fmt.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer relative flex flex-col justify-between ${
                    isSelected
                      ? "border-2 border-indigo-600 bg-indigo-50/40 dark:bg-indigo-950/40 shadow-sm"
                      : "border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/40 hover:border-slate-300 dark:hover:border-slate-600 opacity-70 hover:opacity-100"
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className={`p-1.5 rounded-lg ${isSelected ? "bg-indigo-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                        {fmt.title}
                      </h4>
                    </div>
                    <div className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                      isSelected
                        ? "bg-indigo-600 border-indigo-600 text-white"
                        : "border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800"
                    }`}>
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                    {fmt.description}
                  </p>
                  <span className="text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 mt-2">
                    {fmt.rule}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Error notification if any */}
        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Action Button */}
        <div className="flex items-center justify-end pt-2">
          <button
            type="button"
            onClick={onAnalyze}
            disabled={isAnalyzing || (!projectText.trim() && !fileData)}
            className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-slate-900 hover:bg-slate-800 active:bg-black dark:bg-indigo-600 dark:hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-slate-200 dark:shadow-none transition-all cursor-pointer"
          >
            {isAnalyzing ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Analyzing & Generating {selectedFormats.length > 1 ? `${selectedFormats.length} Formats` : selectedFormats[0]}...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-indigo-400 dark:text-white" />
                <span>
                  Analyze & Generate {selectedFormats.length === ALL_FORMAT_TYPES.length ? "All Formats" : selectedFormats.length === 1 ? selectedFormats[0] : `${selectedFormats.length} Formats`}
                </span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

