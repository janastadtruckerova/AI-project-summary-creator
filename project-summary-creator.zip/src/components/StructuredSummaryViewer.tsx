import React, { useState } from "react";
import {
  Copy,
  Check,
  Edit2,
  Save,
  AlertTriangle,
  Sparkles,
  FileText,
  CheckCircle2,
  BookmarkPlus
} from "lucide-react";
import { ProjectSummary } from "../types";

interface StructuredSummaryViewerProps {
  summary: ProjectSummary;
  onUpdateSummary: (updated: ProjectSummary) => void;
  onSaveToLibrary: () => void;
  isSaved: boolean;
}

export const StructuredSummaryViewer: React.FC<StructuredSummaryViewerProps> = ({
  summary,
  onUpdateSummary,
  onSaveToLibrary,
  isSaved,
}) => {
  const [copiedRaw, setCopiedRaw] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<ProjectSummary>(summary);

  const isMissing = (val: string) =>
    !val || val.toLowerCase().includes("not identified in project documentation");

  const handleCopyRaw = () => {
    const rawTemplate = `------------------------------------
PROJECT SUMMARY
------------------------------------

Problem
${summary.problem}

Solution
${summary.solution}

AI Tools Used
${summary.aiToolsUsed}

Output
${summary.output}

Business Value
${summary.businessValue}

------------------------------------`;

    navigator.clipboard.writeText(rawTemplate);
    setCopiedRaw(true);
    setTimeout(() => setCopiedRaw(false), 2000);
  };

  const handleSaveEdit = () => {
    const rawTemplate = `------------------------------------
PROJECT SUMMARY
------------------------------------

Problem
${editForm.problem}

Solution
${editForm.solution}

AI Tools Used
${editForm.aiToolsUsed}

Output
${editForm.output}

Business Value
${editForm.businessValue}

------------------------------------`;

    onUpdateSummary({
      ...editForm,
      rawSummaryTemplate: rawTemplate,
    });
    setIsEditing(false);
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden transition-all">
      {/* Header bar */}
      <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Project Summary
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Structured extraction following official guidelines
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={onSaveToLibrary}
            className={`inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              isSaved
                ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800"
                : "bg-indigo-50 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900 border border-indigo-200 dark:border-indigo-800"
            }`}
          >
            {isSaved ? <CheckCircle2 className="w-3.5 h-3.5" /> : <BookmarkPlus className="w-3.5 h-3.5" />}
            <span>{isSaved ? "Saved to Library" : "Save Summary"}</span>
          </button>

          {!isEditing ? (
            <button
              type="button"
              onClick={() => {
                setEditForm(summary);
                setIsEditing(true);
              }}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-colors"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>Edit Fields</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSaveEdit}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Changes</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleCopyRaw}
            className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-colors"
          >
            {copiedRaw ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span className="text-emerald-600 dark:text-emerald-400">Copied Template</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Template</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Structured Content Area */}
      <div className="p-6 font-mono text-sm">
        <div className="text-slate-400 dark:text-slate-500 font-bold select-none text-xs">
          ------------------------------------
        </div>
        <div className="text-indigo-600 dark:text-indigo-400 font-bold my-1 tracking-wider text-xs uppercase">
          PROJECT SUMMARY
        </div>
        <div className="text-slate-400 dark:text-slate-500 font-bold select-none text-xs mb-6">
          ------------------------------------
        </div>

        {/* Sections */}
        <div className="space-y-6 font-sans">
          {/* Problem */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Problem
              </h3>
              {isMissing(summary.problem) && (
                <span className="inline-flex items-center space-x-1 px-2 py-0.5 text-[10px] font-medium rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Missing in doc</span>
                </span>
              )}
            </div>

            {isEditing ? (
              <textarea
                rows={3}
                value={editForm.problem}
                onChange={(e) => setEditForm({ ...editForm, problem: e.target.value })}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500"
              />
            ) : (
              <div
                className={`p-3.5 rounded-xl border ${
                  isMissing(summary.problem)
                    ? "bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 text-amber-900 dark:text-amber-200 italic"
                    : "bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-200"
                }`}
              >
                <p className="text-xs leading-relaxed whitespace-pre-line">
                  {summary.problem}
                </p>
              </div>
            )}
          </div>

          {/* Solution */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Solution
              </h3>
              {isMissing(summary.solution) && (
                <span className="inline-flex items-center space-x-1 px-2 py-0.5 text-[10px] font-medium rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Missing in doc</span>
                </span>
              )}
            </div>

            {isEditing ? (
              <textarea
                rows={3}
                value={editForm.solution}
                onChange={(e) => setEditForm({ ...editForm, solution: e.target.value })}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500"
              />
            ) : (
              <div
                className={`p-3.5 rounded-xl border ${
                  isMissing(summary.solution)
                    ? "bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 text-amber-900 dark:text-amber-200 italic"
                    : "bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-200"
                }`}
              >
                <p className="text-xs leading-relaxed whitespace-pre-line">
                  {summary.solution}
                </p>
              </div>
            )}
          </div>

          {/* AI Tools Used */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                AI Tools Used
              </h3>
              {isMissing(summary.aiToolsUsed) && (
                <span className="inline-flex items-center space-x-1 px-2 py-0.5 text-[10px] font-medium rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Missing in doc</span>
                </span>
              )}
            </div>

            {isEditing ? (
              <textarea
                rows={2}
                value={editForm.aiToolsUsed}
                onChange={(e) => setEditForm({ ...editForm, aiToolsUsed: e.target.value })}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500"
              />
            ) : (
              <div
                className={`p-3.5 rounded-xl border ${
                  isMissing(summary.aiToolsUsed)
                    ? "bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 text-amber-900 dark:text-amber-200 italic"
                    : "bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-200 font-mono"
                }`}
              >
                <p className="text-xs leading-relaxed whitespace-pre-line">
                  {summary.aiToolsUsed}
                </p>
              </div>
            )}
          </div>

          {/* Output */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Output
              </h3>
              {isMissing(summary.output) && (
                <span className="inline-flex items-center space-x-1 px-2 py-0.5 text-[10px] font-medium rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Missing in doc</span>
                </span>
              )}
            </div>

            {isEditing ? (
              <textarea
                rows={2}
                value={editForm.output}
                onChange={(e) => setEditForm({ ...editForm, output: e.target.value })}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500"
              />
            ) : (
              <div
                className={`p-3.5 rounded-xl border ${
                  isMissing(summary.output)
                    ? "bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 text-amber-900 dark:text-amber-200 italic"
                    : "bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-200"
                }`}
              >
                <p className="text-xs leading-relaxed whitespace-pre-line">
                  {summary.output}
                </p>
              </div>
            )}
          </div>

          {/* Business Value */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Business Value
              </h3>
              {isMissing(summary.businessValue) && (
                <span className="inline-flex items-center space-x-1 px-2 py-0.5 text-[10px] font-medium rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Missing in doc</span>
                </span>
              )}
            </div>

            {isEditing ? (
              <textarea
                rows={3}
                value={editForm.businessValue}
                onChange={(e) => setEditForm({ ...editForm, businessValue: e.target.value })}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs focus:ring-2 focus:ring-indigo-500"
              />
            ) : (
              <div
                className={`p-3.5 rounded-xl border ${
                  isMissing(summary.businessValue)
                    ? "bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 text-amber-900 dark:text-amber-200 italic"
                    : "bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-200"
                }`}
              >
                <p className="text-xs leading-relaxed whitespace-pre-line">
                  {summary.businessValue}
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="mt-6 text-slate-400 dark:text-slate-500 font-bold select-none text-xs">
          ------------------------------------
        </div>
      </div>
    </div>
  );
};
