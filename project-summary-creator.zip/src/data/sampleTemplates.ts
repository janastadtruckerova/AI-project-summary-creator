import { SampleProjectTemplate } from "../types";

export const SAMPLE_TEMPLATES: SampleProjectTemplate[] = [
  {
    id: "ai-support-bot",
    title: "Enterprise AI Support Agent & Intelligent Routing",
    category: "AI & NLP",
    badgeColor: "bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800",
    description: "Automating Tier-1 support inquiries and ticket triage using RAG and LLM models.",
    content: `PROJECT DOCUMENTATION: Enterprise AI Support Agent & Intelligent Routing

PROBLEM / CHALLENGE:
The customer service team at GlobalTech Solutions was overwhelmed with over 25,000 monthly support tickets. Average response times exceeded 14 hours, leading to customer churn and low CSAT scores (62%). Support representatives spent 60% of their day answering repetitive FAQs (e.g., password resets, order tracking, invoice copies) instead of resolving complex customer issues.

SOLUTION ARCHITECTURE:
We designed and implemented a Retrieval-Augmented Generation (RAG) customer support assistant integrated directly into Zendesk and Slack. The solution ingests knowledge base articles, product documentation, and historic resolved tickets into a vector database. Incoming queries are analyzed for user intent and sentiment, automatically serving instant answers for common questions or categorizing and routing complex cases to the appropriate specialist team with contextual summaries.

AI TOOLS & TECHNOLOGIES USED:
- Gemini 3.6 Flash (LLM for intent classification, summary generation, and response drafting)
- Pinecone (Vector database for similarity search across 10,000+ support docs)
- LangChain (Agentic orchestration & prompt engineering framework)
- Python & FastAPI (Backend microservice layer)
- Zendesk REST API & Webhooks (Support ticket integration)

FINAL DELIVERABLE / OUTPUT:
- An omni-channel conversational AI chatbot widget deployed on web and mobile platforms.
- Intelligent ticket classification service auto-tagging priority, urgency, and product category.
- Support Agent Copilot dashboard providing suggested responses for human support staff.

BUSINESS VALUE & IMPACT:
- Deflected 42% of incoming Tier-1 support inquiries automatically without human intervention.
- Reduced average ticket resolution time from 14 hours down to 18 minutes.
- Increased Customer Satisfaction Score (CSAT) from 62% to 89% within 90 days.
- Generated $340,000 in annual operational savings by optimizing team bandwidth.`,
  },
  {
    id: "predictive-churn",
    title: "Predictive Subscriber Churn Analytics Engine",
    category: "Data Analytics",
    badgeColor: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800",
    description: "Machine learning analytics platform predicting customer churn and triggering retention.",
    content: `PROJECT CHARTER: Predictive Subscriber Churn Analytics Engine

CHALLENGE:
SaaS platform CloudMetrics was experiencing a subtle but steady 4.8% monthly subscriber churn rate among mid-tier business accounts. Marketing and Customer Success teams lacked visibility into early warning indicators and were attempting manual outreach only after customers initiated account cancellation.

PROPOSED SOLUTION:
Developed an end-to-end predictive machine learning pipeline that aggregates historical user activity logs, feature usage frequency, support ticket volume, billing events, and NPS feedback. Built a classification model that computes daily churn risk scores (0-100%) for every active account. High-risk accounts automatically trigger automated customer success playbook tasks in Salesforce and targeted email discount offers.

TECHNOLOGY STACK & AI TOOLS:
- Google Cloud BigQuery ML & Vertex AI (Data warehouse & ML pipeline execution)
- XGBoost & Scikit-Learn (Predictive supervised classification model)
- Looker & D3.js (Executive analytics dashboard and trend reporting)
- Python (Pandas, NumPy, Featuretools for automated feature engineering)
- Salesforce CRM Webhooks (Automated trigger integration)

OUTPUT & DELIVERABLES:
- Daily automated Churn Probability Scoring Pipeline running across 150,000 subscriber accounts.
- Interactive Executive Retention Dashboard displaying churn drivers, cohort analysis, and at-risk revenue.
- Automated Customer Success Alert System alerting account managers when account engagement drops below safety threshold.

BUSINESS VALUE:
- Successfully identified 84% of churn-prone accounts at least 30 days prior to renewal.
- Decreased overall monthly churn rate from 4.8% to 2.9% within two quarters.
- Saved an estimated $1.25M in Annual Recurring Revenue (ARR).
- Improved Customer Success team outreach efficiency by 300% through targeted prioritization.`,
  },
  {
    id: "invoice-automation",
    title: "Intelligent Invoice OCR & ERP Data Extraction",
    category: "Automation",
    badgeColor: "bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800",
    description: "Automating document data extraction and SAP ERP synchronization using Document AI.",
    content: `PROJECT DOCUMENTATION: Intelligent Invoice OCR & ERP Data Extraction Pipeline

PROBLEM STATEMENT:
Accounts Payable at Apex Logistics processed over 8,000 vendor invoices per month received via email in varied formats (PDFs, scans, JPEGs). Manual data entry into SAP ERP required 15 minutes per invoice, resulted in a 6.2% error rate, caused vendor payment delays, and cost significant labor hours.

AUTOMATION SOLUTION:
Constructed a serverless document intelligence pipeline. Incoming emails automatically trigger an serverless function that extracts attachments, passes them through a multimodal Document AI optical character recognition (OCR) model, extracts line items, tax IDs, invoice numbers, and due dates, performs validation against existing purchase orders, and posts clean transaction records to SAP ERP.

AI TOOLS & PLATFORMS USED:
- Google Cloud Document AI (Specialized Invoice Parser model)
- Python / Express Node.js (Microservice backend & validation logic)
- SAP Cloud ERP API (Automated journal entry creation)
- Google Cloud Storage & Pub/Sub (Event-driven pipeline orchestration)

DELIVERABLE:
- Fully automated, hands-free Accounts Payable document processing pipeline.
- Human-in-the-Loop Validation UI for flag-raised exceptions (e.g., mismatched totals or unknown vendors).
- Audit log dashboard recording processing confidence metrics and throughput.

BUSINESS VALUE & ROI:
- Cut invoice processing time from 15 minutes down to 12 seconds per document.
- Achieved 99.4% field extraction accuracy across multi-lingual vendor formats.
- Eliminated 850 monthly staff hours of repetitive manual data entry, enabling team redeployment to strategic vendor negotiations.
- Reduced invoice processing cost from $8.50 per invoice to $0.42.`,
  },
  {
    id: "supply-chain-digital-transform",
    title: "Digital Transformation: Dynamic Supply Chain Sensing",
    category: "Digital Transformation",
    badgeColor: "bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-800",
    description: "Replacing legacy manual spreadsheets with cloud IoT forecasting and dynamic inventory control.",
    content: `EXECUTIVE SUMMARY & BRIEF: Supply Chain Digital Transformation Initiative

BACKGROUND & PROBLEM:
Retailer OmniMarket operated legacy inventory planning systems reliant on disconnected Excel spreadsheets updated weekly by store managers. Outdated stock visibility led to frequent stockouts on popular items (12% loss of sales) and $4M in excess holding inventory stranded in regional warehouses.

DIGITAL TRANSFORMATION STRATEGY:
Migrated store inventory, supplier lead times, and POS sales data into a unified Cloud Data Lake. Built dynamic AI demand-forecasting models incorporating local weather forecasts, economic trends, and historical seasonality. Connected automated reorder recommendations directly to supplier EDI gateways.

TOOLS, MODELS & ARCHITECTURE:
- AWS SageMaker & Prophet (Time-series demand forecasting models)
- Snowflake (Cloud Data Lakehouse consolidating 40+ retail stores)
- PowerBI (Real-time store stock level visualization)
- Python & Apache Airflow (ETL pipeline scheduling)

PROJECT OUTPUT:
- Unified Real-Time Inventory Control Portal accessible across store managers, buyers, and logistics team.
- Automated Purchase Order Generation System with supplier EDI integration.
- Predictive Demand Heatmaps forecasting regional stock requirements 14 days ahead.

VALUE GENERATED:
- Reduced retail out-of-stock incidents by 34%, capturing $1.8M in recovered revenue.
- Decreased overall warehouse excess inventory holding costs by $2.1M (a 28% reduction).
- Reduced store replenishment planning cycle time from 3 days to 15 minutes per week.`,
  },
  {
    id: "edge-case-missing-info",
    title: "Internal Search Concept (Testing Missing Details)",
    category: "Edge Case (Missing Info)",
    badgeColor: "bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border-rose-200 dark:border-rose-800",
    description: "An incomplete proposal document to verify how missing fields are handled explicitly.",
    content: `MEMORANDUM: Internal Knowledge Search Initiative (Draft Proposal)

PROBLEM:
Employees spend too much time searching across Google Drive and local drives for company policy documents and technical guides.

SOLUTION:
Build an internal search box where team members can type questions.

NOTE FOR SUMMARY CREATOR:
This document does NOT specify AI tools, technical outputs, or quantitative business value metrics.`,
  },
];
