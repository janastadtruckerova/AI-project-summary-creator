export type FormatType = 
  | "Portfolio Summary" 
  | "LinkedIn Summary" 
  | "CV Summary" 
  | "Executive Summary";

export interface ProjectSummary {
  problem: string;
  solution: string;
  aiToolsUsed: string;
  output: string;
  businessValue: string;
  rawSummaryTemplate: string;
}

export type FormattedOutputs = Partial<Record<FormatType, string>>;

export interface SavedProject {
  id: string;
  title: string;
  timestamp: string;
  sourceType: "pasted" | "file" | "template";
  fileName?: string;
  rawText: string;
  summary: ProjectSummary;
  formattedOutputs: FormattedOutputs;
  activeFormat: FormatType;
}

export interface SampleProjectTemplate {
  id: string;
  title: string;
  category: "AI & NLP" | "Data Analytics" | "Automation" | "Digital Transformation" | "Edge Case (Missing Info)";
  badgeColor: string;
  description: string;
  content: string;
}
