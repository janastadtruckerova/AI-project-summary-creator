import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { DocumentInputPanel } from "./components/DocumentInputPanel";
import { StructuredSummaryViewer } from "./components/StructuredSummaryViewer";
import { FormatGenerator } from "./components/FormatGenerator";
import { SavedSummariesModal } from "./components/SavedSummariesModal";
import {
  FormatType,
  FormattedOutputs,
  ProjectSummary,
  SavedProject
} from "./types";
import { Sparkles, ArrowDown, HelpCircle, CheckCircle2, ShieldCheck } from "lucide-react";

export default function App() {
  const [projectText, setProjectText] = useState<string>("");
  const [fileData, setFileData] = useState<{
    data: string;
    mimeType: string;
    name: string;
  } | null>(null);

  const [summary, setSummary] = useState<ProjectSummary | null>(null);
  const [formattedOutputs, setFormattedOutputs] = useState<FormattedOutputs>({});
  const [activeFormat, setActiveFormat] = useState<FormatType>("Portfolio Summary");
  const [selectedFormats, setSelectedFormats] = useState<FormatType[]>(["Portfolio Summary"]);

  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [isGeneratingFormat, setIsGeneratingFormat] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [savedProjects, setSavedProjects] = useState<SavedProject[]>([]);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Initialize dark mode and saved projects from local storage
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") {
      setDarkMode(false);
      document.documentElement.classList.remove("dark");
    } else {
      setDarkMode(true);
      document.documentElement.classList.add("dark");
    }

    try {
      const storedProjects = localStorage.getItem("project_summary_creator_saved");
      if (storedProjects) {
        setSavedProjects(JSON.parse(storedProjects));
      }
    } catch (e) {
      console.error("Failed to parse saved projects from local storage", e);
    }
  }, []);

  const toggleDarkMode = () => {
    const nextTheme = !darkMode;
    setDarkMode(nextTheme);
    if (nextTheme) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  };

  // Analyze Project Documentation & Auto-Generate Selected Format(s)
  const handleAnalyze = async () => {
    if (!projectText.trim() && !fileData) {
      setError("Please enter project text or upload a document.");
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectText,
          fileData,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to analyze document.");
      }

      const summaryResult: ProjectSummary = await response.json();
      setSummary(summaryResult);
      setFormattedOutputs({});

      // Set active format to the first selected format
      const formatsToGen = selectedFormats.length > 0 ? selectedFormats : ["Portfolio Summary" as FormatType];
      setActiveFormat(formatsToGen[0]);

      // Automatically generate chosen format(s) in parallel
      const generatedResults: FormattedOutputs = {};
      await Promise.all(
        formatsToGen.map(async (fmt) => {
          try {
            const fmtRes = await fetch("/api/generate-format", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                summary: summaryResult,
                format: fmt,
                originalText: projectText,
              }),
            });
            if (fmtRes.ok) {
              const resData = await fmtRes.json();
              generatedResults[fmt] = resData.content;
            }
          } catch (err) {
            console.error(`Failed auto-generating format ${fmt}`, err);
          }
        })
      );

      setFormattedOutputs(generatedResults);

      // Scroll smoothly down to summary viewer
      setTimeout(() => {
        const el = document.getElementById("structured-summary-section");
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } catch (err: any) {
      console.error("Error analyzing project:", err);
      setError(err.message || "An unexpected error occurred during analysis.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Generate Specific Output Format
  const handleGenerateFormat = async (formatToGenerate: FormatType) => {
    if (!summary) return;

    setIsGeneratingFormat(true);
    setError(null);

    try {
      const response = await fetch("/api/generate-format", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          summary,
          format: formatToGenerate,
          originalText: projectText,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to generate ${formatToGenerate}.`);
      }

      const result = await response.json();

      setFormattedOutputs((prev) => ({
        ...prev,
        [formatToGenerate]: result.content,
      }));
    } catch (err: any) {
      console.error("Error generating format:", err);
      setError(err.message || `Failed to generate ${formatToGenerate}.`);
    } finally {
      setIsGeneratingFormat(false);
    }
  };

  const handleUpdateFormatContent = (fmt: FormatType, newContent: string) => {
    setFormattedOutputs((prev) => ({
      ...prev,
      [fmt]: newContent,
    }));
  };

  // Save current project state to saved projects
  const handleSaveToLibrary = () => {
    if (!summary) return;

    const titleExtract =
      summary.solution && summary.solution !== "Not identified in project documentation."
        ? summary.solution.slice(0, 40) + "..."
        : projectText.slice(0, 40) || "Untitled Project Summary";

    const newSavedItem: SavedProject = {
      id: Date.now().toString(),
      title: titleExtract,
      timestamp: new Date().toISOString(),
      sourceType: fileData ? "file" : "pasted",
      fileName: fileData?.name,
      rawText: projectText,
      summary,
      formattedOutputs,
      activeFormat,
    };

    const updated = [newSavedItem, ...savedProjects.filter((p) => p.id !== newSavedItem.id)];
    setSavedProjects(updated);
    localStorage.setItem("project_summary_creator_saved", JSON.stringify(updated));
  };

  const isCurrentSaved = !!savedProjects.find(
    (p) => p.summary.rawSummaryTemplate === summary?.rawSummaryTemplate
  );

  const handleDeleteSavedProject = (id: string) => {
    const updated = savedProjects.filter((p) => p.id !== id);
    setSavedProjects(updated);
    localStorage.setItem("project_summary_creator_saved", JSON.stringify(updated));
  };

  const handleClearAllSaved = () => {
    setSavedProjects([]);
    localStorage.removeItem("project_summary_creator_saved");
  };

  const handleSelectSavedProject = (proj: SavedProject) => {
    setProjectText(proj.rawText);
    setSummary(proj.summary);
    setFormattedOutputs(proj.formattedOutputs);
    setActiveFormat(proj.activeFormat);
  };

  const handleReset = () => {
    setProjectText("");
    setFileData(null);
    setSummary(null);
    setFormattedOutputs({});
    setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors font-sans pb-16">
      {/* Header */}
      <Header
        savedCount={savedProjects.length}
        onOpenSaved={() => setIsSavedModalOpen(true)}
        onReset={handleReset}
        darkMode={darkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      {/* Main Container */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
        {/* Intro banner */}
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-500" />
            <span>Fact-Based Analysis • Zero Hallucination Policy</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Transform AI & Tech Projects into Structured Summaries
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Upload or paste project documentation to extract Problem, Solution, AI Tools Used, Output, and Business Value, then generate tailored Portfolio, LinkedIn, CV, or Executive summaries.
          </p>
        </div>

        {/* Step 1: Input & Analysis */}
        <DocumentInputPanel
          projectText={projectText}
          setProjectText={setProjectText}
          fileData={fileData}
          setFileData={setFileData}
          selectedFormats={selectedFormats}
          setSelectedFormats={setSelectedFormats}
          onAnalyze={handleAnalyze}
          isAnalyzing={isAnalyzing}
          error={error}
        />

        {/* Step 2: Extracted Structured Summary */}
        {summary && (
          <div id="structured-summary-section" className="space-y-8 pt-4">
            <div className="flex items-center justify-center space-x-2 text-indigo-500 my-2">
              <ArrowDown className="w-5 h-5 animate-bounce" />
            </div>

            <StructuredSummaryViewer
              summary={summary}
              onUpdateSummary={setSummary}
              onSaveToLibrary={handleSaveToLibrary}
              isSaved={isCurrentSaved}
            />

            {/* Step 3: Select Format & Generate tailored outputs */}
            <FormatGenerator
              summary={summary}
              formattedOutputs={formattedOutputs}
              activeFormat={activeFormat}
              setActiveFormat={setActiveFormat}
              onGenerateFormat={handleGenerateFormat}
              onUpdateFormatContent={handleUpdateFormatContent}
              isGenerating={isGeneratingFormat}
              originalText={projectText}
            />
          </div>
        )}
      </main>

      {/* Saved Projects Modal */}
      <SavedSummariesModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedProjects={savedProjects}
        onSelectProject={handleSelectSavedProject}
        onDeleteProject={handleDeleteSavedProject}
        onClearAll={handleClearAllSaved}
      />
    </div>
  );
}
