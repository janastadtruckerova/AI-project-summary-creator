import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));

const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is not configured.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// Healthcheck API
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Analyze Project Documentation endpoint
const MODELS_TO_TRY = ["gemini-3.6-flash", "gemini-2.5-flash"];

async function generateContentWithFallback(ai: GoogleGenAI, requestConfig: any) {
  let lastError: any = null;

  for (const modelName of MODELS_TO_TRY) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const response = await ai.models.generateContent({
          ...requestConfig,
          model: modelName,
        });
        return response;
      } catch (err: any) {
        lastError = err;
        const errStr = String(err?.message || err);
        const isTransient =
          errStr.includes("503") ||
          errStr.includes("429") ||
          errStr.includes("UNAVAILABLE") ||
          errStr.includes("RESOURCE_EXHAUSTED") ||
          errStr.includes("high demand");

        if (isTransient && attempt < 3) {
          console.warn(`Attempt ${attempt} for model ${modelName} failed with transient error (${errStr}). Retrying in ${attempt * 1000}ms...`);
          await new Promise((resolve) => setTimeout(resolve, attempt * 1000));
        } else if (isTransient) {
          console.warn(`Model ${modelName} failed after 3 attempts with transient error. Trying fallback model...`);
          break; // try next model in MODELS_TO_TRY
        } else {
          throw err;
        }
      }
    }
  }

  throw lastError;
}

app.post("/api/analyze", async (req, res) => {
  try {
    const { projectText, fileData } = req.body;

    if (!projectText && !fileData) {
      return res.status(400).json({
        error: "Please provide either project text or an uploaded file document.",
      });
    }

    const ai = getGeminiClient();

    const systemInstruction = `You are Project Summary Creator, an AI assistant specialized in analyzing AI, data analytics, automation, and digital transformation projects.

Your job is to analyze the provided project document or description and identify:
1. Problem (Describe the problem or challenge addressed by the project)
2. Solution (Describe how the problem was solved)
3. AI Tools Used (List all identified AI tools, platforms, models, and technologies)
4. Output (Describe the final deliverable or result)
5. Business Value (Describe the value, impact, benefits, or improvements created by the project)

STRICT RULES:
- Use ONLY information found in the provided documentation/text.
- DO NOT invent facts, numbers, or project details.
- If any information is missing or not explicitly stated in the document, set that field to: "Not identified in project documentation."
- Keep language professional, clear, and objective.`;

    let contents: any = [];

    if (fileData && fileData.data && fileData.mimeType) {
      const inlinePart = {
        inlineData: {
          data: fileData.data,
          mimeType: fileData.mimeType,
        },
      };
      const textPart = {
        text: projectText
          ? `Analyze this project document along with the following text notes:\n${projectText}`
          : `Analyze this uploaded project document.`,
      };
      contents = [inlinePart, textPart];
    } else {
      contents = [
        `Analyze the following project documentation/description:\n\n${projectText}`,
      ];
    }

    const response = await generateContentWithFallback(ai, {
      contents,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            problem: {
              type: Type.STRING,
              description: "The problem or challenge addressed by the project",
            },
            solution: {
              type: Type.STRING,
              description: "How the problem was solved",
            },
            aiToolsUsed: {
              type: Type.STRING,
              description: "All identified AI tools, platforms, models, and technologies",
            },
            output: {
              type: Type.STRING,
              description: "The final deliverable or result",
            },
            businessValue: {
              type: Type.STRING,
              description: "The value, impact, benefits, or improvements created by the project",
            },
          },
          required: ["problem", "solution", "aiToolsUsed", "output", "businessValue"],
        },
      },
    });

    const text = response.text || "{}";
    const parsedData = JSON.parse(text);

    // Format template exactly as required
    const rawSummaryTemplate = `------------------------------------
PROJECT SUMMARY
------------------------------------

Problem
${parsedData.problem || "Not identified in project documentation."}

Solution
${parsedData.solution || "Not identified in project documentation."}

AI Tools Used
${parsedData.aiToolsUsed || "Not identified in project documentation."}

Output
${parsedData.output || "Not identified in project documentation."}

Business Value
${parsedData.businessValue || "Not identified in project documentation."}

------------------------------------`;

    return res.json({
      problem: parsedData.problem || "Not identified in project documentation.",
      solution: parsedData.solution || "Not identified in project documentation.",
      aiToolsUsed: parsedData.aiToolsUsed || "Not identified in project documentation.",
      output: parsedData.output || "Not identified in project documentation.",
      businessValue: parsedData.businessValue || "Not identified in project documentation.",
      rawSummaryTemplate,
    });
  } catch (error: any) {
    console.error("Error in /api/analyze:", error);
    const msg = error?.message || String(error);
    const isDemandError = msg.includes("503") || msg.includes("high demand") || msg.includes("UNAVAILABLE");
    return res.status(503).json({
      error: isDemandError
        ? "The AI service is experiencing high temporary demand. Please wait a few seconds and try clicking Analyze again."
        : msg || "Failed to analyze project document.",
    });
  }
});

// Generate Specific Output Format endpoint
app.post("/api/generate-format", async (req, res) => {
  try {
    const { summary, format, originalText } = req.body;

    if (!summary || !format) {
      return res.status(400).json({ error: "Missing summary or output format." });
    }

    const ai = getGeminiClient();
    const normalizedFormat = String(format).toUpperCase();

    let formatRules = "";
    if (normalizedFormat.includes("PORTFOLIO")) {
      formatRules = `PORTFOLIO SUMMARY:
Create a structured, detailed project description suitable for a personal AI/Data portfolio.
Cover: Overview, Problem Statement, Solution Architecture & Approach, AI Tools & Technologies, Key Deliverables/Outputs, and Measurable Business Impact.`;
    } else if (normalizedFormat.includes("LINKEDIN")) {
      formatRules = `LINKEDIN SUMMARY:
Create an engaging professional LinkedIn post.
Focus on learning outcomes, project impact, and practical application.
STRICT WORD COUNT RULE: Length must be strictly between 150 and 250 words.
Use clean formatting with line breaks and subtle emojis if appropriate.`;
    } else if (normalizedFormat.includes("CV")) {
      formatRules = `CV SUMMARY:
Create 3-5 concise, high-impact resume bullet points.
Start each point with a strong action verb.
Focus on achievements, tools used, and quantified business impact.`;
    } else if (normalizedFormat.includes("EXECUTIVE")) {
      formatRules = `EXECUTIVE SUMMARY:
Create a business-focused summary for managers and executives/stakeholders.
Use non-technical, accessible language where possible.
STRICT WORD COUNT RULE: Maximum length is 200 words.`;
    } else {
      return res.status(400).json({ error: "Invalid format requested." });
    }

    const systemInstruction = `You are Project Summary Creator.
Your task is to take a structured Project Summary and transform it into a specific output format (${format}).

CRITICAL CONSTRAINTS:
1. Use ONLY information provided in the input Project Summary (and original project text if included).
2. DO NOT invent facts, metrics, tools, or details not found in the source material.
3. If information is missing from the source, explicitly state that it was not identified in the project documentation.
4. Adhere strictly to the rules for ${format}:
${formatRules}`;

    const promptText = `Source Project Summary:
Problem: ${summary.problem}
Solution: ${summary.solution}
AI Tools Used: ${summary.aiToolsUsed}
Output: ${summary.output}
Business Value: ${summary.businessValue}

${originalText ? `Original Documentation Excerpt:\n${originalText}` : ""}

Please generate the ${format}.`;

    const response = await generateContentWithFallback(ai, {
      contents: promptText,
      config: {
        systemInstruction,
      },
    });

    const generatedContent = response.text || "";

    return res.json({
      format,
      content: generatedContent,
    });
  } catch (error: any) {
    console.error("Error in /api/generate-format:", error);
    const msg = error?.message || String(error);
    const isDemandError = msg.includes("503") || msg.includes("high demand") || msg.includes("UNAVAILABLE");
    return res.status(503).json({
      error: isDemandError
        ? "The AI service is experiencing high temporary demand. Please try again in a few seconds."
        : msg || "Failed to generate format summary.",
    });
  }
});

// Setup Vite development server or production static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
